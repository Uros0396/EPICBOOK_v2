function createBookListItem(book) {
    const listItem = document.createElement('li');
    listItem.innerHTML = `
        <p>${book.title}</p>
        <a href="dettagli.html?id=${book.asin}">Dettagli</a>
    `;
    return listItem;
}

// Recupera i libri dall'API e popola la lista
fetch('https://striveschool-api.herokuapp.com/books')
    .then(response => response.json())
    .then(data => {
        const bookList = document.getElementById('book-list');
        data.forEach(book => {
            const listItem = createBookListItem(book);
            bookList.appendChild(listItem);
        });
    })
    .catch(error => {
        console.error("Errore nel recupero della lista dei libri:", error);
    });
